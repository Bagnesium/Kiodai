# Kiodai v2 saved-artifact report

Real local development smoke on an exposed trajectory; not the frozen OpenRouter comparison.

Primary: each full trajectory and paired differences. Micro totals are descriptive. Sequential steps and model calls are not replications. Undefined denominators remain null.

| Trajectory | Method | TP | FP | FN | Precision | Recall | Set-F1 | Calls | Queries |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| v2_hidden_91320 | A2 | None | None | None | None | None | None | 4 | 0 |

Full diagnostics, paired differences, resource accounting and trace paths: `report.json`.
API costs and tokens are unavailable for MOCK. No verified billing record was obtained.
Native PM-Bench removes completed handles. Execution failure, uncertainty and duplicate protection are separately tested local lifecycle mechanics.
