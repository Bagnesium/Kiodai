# Kiodai v2 saved-artifact report

MOCK verifies mechanics only; these are not model-performance results. Intact original 20-step story. Cooling-only mocked semantics; all other errors retained. Not a comparator result.

Primary: each full trajectory and paired differences. Micro totals are descriptive. Sequential steps and model calls are not replications. Undefined denominators remain null.

| Trajectory | Method | TP | FP | FN | Precision | Recall | Set-F1 | Calls | Queries |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| known-original-followup | A2 | 1 | 0 | 10 | 1.0000 | 0.0909 | 0.1667 | 40 | 5 |

Full diagnostics, paired differences, resource accounting and trace paths: `report.json`.
API costs and tokens are unavailable for MOCK. No verified billing record was obtained.
Native PM-Bench removes completed handles. Execution failure, uncertainty and duplicate protection are separately tested local lifecycle mechanics.
